<?php
// include ('Header.php'); ?>
<html>
<!doctype html>
<lang="en">

	<head>
		<title>Login 10</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<link href="https://fonts1.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css1/font-awesome.min.css">

		<link rel="stylesheet" href="css/style.css">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <!-- <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css"> -->
	</head>

	<body class="hero-wrap ftco-degree-bg" style="background-image: url('images1/bg-12.jpg');background-position: center center; background-size: cover;"
		data-stellar-background-ratio="0.5">
		<section class="ftco-section">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-md-6 text-center mb-5">
						<h2 class="heading-section" style="color:#FFFFFF;">Login</h2>
					</div>
				</div>
				<div class="row justify-content-center">
					<div class="col-md-6 col-lg-4">
						<div class="login-wrap p-0">
							<h3 class="mb-4 text-center" style="color:#FFFFFF;">Have an account?</h3>
							<form action="LoginAction.php" class="signin-form" method="POST">
								<div class="form-group">
									<input type="text" class="form-control" name="txtusername" placeholder="Username"
										required>
								</div>
								<div class="form-group">
									<input id="password-field" type="password" name="txtpassword" class="form-control"
										placeholder="Password" required class="fa fa-fw fa-eye field-icon toggle-password">
								</div>
								<div class="form-group">
									<button type="submit" class="form-control btn btn-primary submit px-3">Sign
										In</button>
								</div>
								<div class="form-group d-md-flex">
									<div class="w-50">
										<label class="checkbox-wrap checkbox-primary">Remember Me
											<input type="checkbox" checked>
											<span class="checkmark"></span>
										</label>
									</div>
									<div class="w-50 text-md-right">
										<a href="#" style="color: #fff">Forgot Password</a>
									</div>
								</div>
							</form>
							<div class="w-100 text-center">
							<a href="CustomerRegistration.php">&mdash; Or Sign Up &mdash;</a>
							</div>
							<!-- <li class="nav-item active"><a href="Index.php" class="nav-link">Home</a>
							<div class="social d-flex text-center">
								<a href="#" class="px-2 py-2 mr-md-1 rounded"><span
										class="ion-logo-facebook mr-2"></span> Facebook</a>
								<a href="#" class="px-2 py-2 ml-md-1 rounded"><span
										class="ion-logo-twitter mr-2"></span> Twitter</a>
							</div> -->
						</div>
					</div>
				</div>
			</div>
		</section>

		<script src="js1/jquery.min.js"></script>
		<script src="js1/popper.js"></script>
		<script src="js1/bootstrap.min.js"></script>
		<script src="js1/main.js"></script>
	</body>
</html>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php 

// include('Footer.php');
?>
